package com.example.menuexperiment;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;


public class MainActivity extends AppCompatActivity {
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

// Customizing the Action Bar
        getSupportActionBar().setTitle("My Custom Toolbar");
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#FF4081")));

        textView = findViewById(R.id.textView);

        // Register the context menu for the TextView
        registerForContextMenu(textView);
    }

    // Inflate the options menu from the XML file
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu); // Inflating the menu
        return true;
    }

    // Handle item selection from the options menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.action_settings) {
            textView.setText("Settings selected");
            return true;
        } else if (itemId == R.id.action_about) {
            textView.setText("About selected");
            return true;
        } else if (itemId == R.id.action_help_faq) {
            textView.setText("FAQ selected");
            return true;
        } else if (itemId == R.id.action_help_contact) {
            textView.setText("Contact Support selected");
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }



    // Create the context menu when long-clicking the TextView
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.main_menu, menu); // Inflating the same menu as options menu
        menu.setHeaderTitle("Choose an option");
    }

    // Handle item selection from the context menu
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.action_settings) {
            textView.setText("Settings selected from context menu");
            return true;
        } else if (itemId == R.id.action_about) {
            textView.setText("About selected from context menu");
            return true;
        } else {
            return super.onContextItemSelected(item);
        }
    }
}
