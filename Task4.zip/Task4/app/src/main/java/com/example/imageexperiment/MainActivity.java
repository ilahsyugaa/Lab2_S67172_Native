package com.example.imageexperiment;

import android.os.Bundle;
import android.widget.Button;
import android.widget.RelativeLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    private RelativeLayout layout;
    private int[] backgrounds = {R.drawable.background_image1, R.drawable.background_image2, R.drawable.background_image3};
    private int currentBackgroundIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        layout = findViewById(R.id.layout);
        Button switchBackgroundButton = findViewById(R.id.switchBackgroundButton);

        Button imageButton = findViewById(R.id.imageButton);
        imageButton.setOnClickListener(v -> {
            Toast.makeText(this, "Image button clicked!", Toast.LENGTH_SHORT).show();
        });





        // Set listener for the background switch button
        switchBackgroundButton.setOnClickListener(v -> {
            // Update background index and set background resource
            currentBackgroundIndex = (currentBackgroundIndex + 1) % backgrounds.length;
            layout.setBackgroundResource(backgrounds[currentBackgroundIndex]);
        });
    }
}
